This font is free and was downloaded from:
http://www.cbrd.co.uk/media/fonts/

Transport Heavy is subject to Crown Copyright, and this font contains public sector information licensed under the Open Government Licence v1.0.

The terms of the Open Government Licence can be read at this address:
http://www.nationalarchives.gov.uk/doc/open-government-licence/